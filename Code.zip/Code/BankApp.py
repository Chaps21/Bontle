import tkinter as tk
from tkinter import messagebox

# Function to read and write balance from/to BankData.txt
def read_balance():
    try:
        with open('BankData.txt', 'r') as file:
            balance = float(file.read().strip())
    except FileNotFoundError:
        # Initialize balance if file does not exist
        balance = 0.0
    return balance

def write_balance(balance):
    with open('BankData.txt', 'w') as file:
        file.write(f'{balance:.2f}')

# Function to log transactions to TransactionLog.txt
def log_transaction(transaction):
    with open('TransactionLog.txt', 'a') as file:
        file.write(transaction + '\n')

# Function to handle deposit
def deposit(amount):
    try:
        amount = float(amount)
        current_balance = read_balance()
        current_balance += amount
        write_balance(current_balance)
        log_transaction(f'Deposit: ${amount:.2f}')
        messagebox.showinfo("Deposit", f"Deposit successful. Current Balance: ${current_balance:.2f}")
    except ValueError:
        messagebox.showerror("Error", "Invalid amount entered.")
    except Exception as e:
        messagebox.showerror("Error", f"Error: {str(e)}")

# Function to handle withdrawal
def withdraw(amount):
    try:
        amount = float(amount)
        current_balance = read_balance()
        if amount > current_balance:
            raise ValueError("Insufficient funds.")
        current_balance -= amount
        write_balance(current_balance)
        log_transaction(f'Withdrawal: ${amount:.2f}')
        messagebox.showinfo("Withdrawal", f"Withdrawal successful. Current Balance: ${current_balance:.2f}")
    except ValueError as e:
        messagebox.showerror("Error", str(e))
    except Exception as e:
        messagebox.showerror("Error", f"Error: {str(e)}")

# Main function to create GUI
def main():
    # Create the main window
    root = tk.Tk()
    root.title("Banking Application")

    # Function to handle deposit button click
    def deposit_button_click():
        amount = amount_entry.get()
        if amount:
            deposit(amount)
        amount_entry.delete(0, tk.END)

    # Function to handle withdrawal button click
    def withdraw_button_click():
        amount = amount_entry.get()
        if amount:
            withdraw(amount)
        amount_entry.delete(0, tk.END)

    # Display current balance label
    current_balance_label = tk.Label(root, text=f"Current Balance: ${read_balance():.2f}")
    current_balance_label.pack(pady=10)

    # Entry field for amount
    amount_label = tk.Label(root, text="Enter amount:")
    amount_label.pack()

    amount_entry = tk.Entry(root)
    amount_entry.pack()

    # Buttons for deposit and withdrawal
    deposit_button = tk.Button(root, text="Deposit", command=deposit_button_click)
    deposit_button.pack(pady=5)

    withdraw_button = tk.Button(root, text="Withdraw", command=withdraw_button_click)
    withdraw_button.pack(pady=5)

    # Run the Tkinter event loop
    root.mainloop()

if __name__ == "_main_":
    main()