from tkinter import *
import random
import string

#Create a password 
def generate_password(): 
 characters = string.ascii_letters + string.digits + string.punctuation
 
 def paswword():
     password =''.join(random.choice(characters) for i in range(12))
 return password

def main():
    password = generate_password()
print(f"Generate Password: {password}")

if __name__ == "_main_": 
    main()
    